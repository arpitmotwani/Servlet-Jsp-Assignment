/**
 * Created by arpitm on 7/29/2016.
 */
function validateForm(frm)
{
    if(frm.signupUsername.value.length==0)
    {
        document.getElementById("signupUsernameErrorSpan").innerHTML="Username required";
        document.getElementById("signupPasswordErrorSpan").innerHTML="";
        document.getElementById("signupConfirmPasswordErrorSpan").innerHTML="";
        return false;
    }
    if(frm.signupPassword.value.length==0)
    {
        document.getElementById("signupPasswordErrorSpan").innerHTML="Password required";
        document.getElementById("signupUsernameErrorSpan").innerHTML="";
        document.getElementById("signupConfirmPasswordErrorSpan").innerHTML="";
        return false;
    }
    if(frm.signupConfirmPassword.value.length==0)
    {
        document.getElementById("signupConfirmPasswordErrorSpan").innerHTML="Password required";
        document.getElementById("signupPasswordErrorSpan").innerHTML="";
        document.getElementById("signupUsernameErrorSpan").innerHTML="";
        return false;
    }
    if(frm.signupConfirmPassword.value!=frm.signupPassword.value)
    {
        document.getElementById("signupConfirmPasswordErrorSpan").innerHTML="Incorred password";
        document.getElementById("signupPasswordErrorSpan").innerHTML="";
        document.getElementById("signupUsernameErrorSpan").innerHTML="";
        return false;
    }
    return true;
}