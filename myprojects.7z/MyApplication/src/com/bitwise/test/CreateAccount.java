package com.bitwise.test;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

/**
 * Created by arpitm on 7/29/2016.
 */
@WebServlet(name = "CreateAccount")
public class CreateAccount extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            String username=(String)request.getAttribute("username");
            String password=(String)request.getAttribute("password");
            RequestDispatcher requestDispatcher;
            HashMap<String,String> usernameAndPasswords=new HashMap<>();
            boolean recordToBeAdded=true;
            int x=0;
            while(x<usernameAndPasswords.size())
            {
                System.out.println(usernameAndPasswords.keySet());
                if(usernameAndPasswords.keySet().equals(username))
                {
                    recordToBeAdded=false;
                    break;
                }
                x++;
            }
                if(recordToBeAdded==true)
                {
                    usernameAndPasswords.put(username,password);
                    request.getSession().setAttribute("usernameAndPasswords",usernameAndPasswords);
                    requestDispatcher=request.getRequestDispatcher("index.jsp");
                    requestDispatcher.forward(request,response);
                }
                else
                {
                    System.out.println("record already exists");
                    requestDispatcher=request.getRequestDispatcher("Signup.jsp");
                    requestDispatcher.include(request,response);
                    requestDispatcher=request.getRequestDispatcher("UsernameAlreadyExistsErrorPage.html");
                    requestDispatcher.include(request,response);
                }
    }
}
