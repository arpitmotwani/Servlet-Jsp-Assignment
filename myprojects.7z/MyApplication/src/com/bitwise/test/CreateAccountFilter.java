package com.bitwise.test;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;
import java.util.HashMap;

/**
 * Created by arpitm on 7/29/2016.
 */
@WebFilter(filterName = "CreateAccountFilter")
public class CreateAccountFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        String username=req.getParameter("signupUsername");
        String password=req.getParameter("signupPassword");
        HashMap<String,String> usernameAndPasswords=new HashMap<>();
        usernameAndPasswords.put(username,password);
        req.setAttribute("usernameAndPasswords",usernameAndPasswords);
//        req.setAttribute("username",username);
//        req.setAttribute("password",password);
        chain.doFilter(req, resp);
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
