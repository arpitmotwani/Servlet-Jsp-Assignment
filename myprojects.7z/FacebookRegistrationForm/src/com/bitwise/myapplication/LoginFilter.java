package com.bitwise.myapplication;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

/**
 * Created by arpitm on 7/27/2016.
 */
@WebFilter(filterName = "LoginFilter")
public class LoginFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        String status=null;
        if(req.getParameter("username")!=null && req.getParameter("password")!=null)
        {
            if(req.getParameter("username").equals("arpit.motwani@bitwiseglobal.com") && req.getParameter("password").equals("arpit123"))
            {
                status="valid";
            }
            else
            {
                status="invalid";
            }
        }
        req.setAttribute("status",status);
        chain.doFilter(req,resp);
    }

    public void init(FilterConfig config) throws ServletException {
    }

}
