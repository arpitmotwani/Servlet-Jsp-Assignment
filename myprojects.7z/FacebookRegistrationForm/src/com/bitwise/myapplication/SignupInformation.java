package com.bitwise.myapplication;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created by arpitm on 7/27/2016.
 */
@WebServlet(name = "SignupInformation")
public class SignupInformation extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter writer=response.getWriter();
        String name=request.getParameter("name");
        String email=request.getParameter("email");
        String gender=request.getParameter("gender");
        String dateOfBirth=request.getParameter("dateOfBirth");
        String contact=request.getParameter("contact");
        String city=request.getParameter("city");

        if(name!=null && email!=null && gender!=null && dateOfBirth!=null && contact!=null && city!=null)
        {
            writer.write("<html>");
            writer.write("<head>");
            writer.write("<title>Create Profile</title>");
            writer.write("</head>");
            writer.write("<body>");
            writer.write("<h3>Facebook</h3>");
            writer.write("<form action=\"/loginForm\" method=\"post\">");
            writer.write("<table>");
            writer.write("<tr>");
            writer.write("<td>Name</td>");
            writer.write("<td><b>"+name);
            writer.write("</b></td>");
            writer.write("</tr>");
            writer.write("<tr>");
            writer.write("<td>Email</td>");
            writer.write("<td><b>"+email);
            writer.write("</b></td>");
            writer.write("</tr>");
            writer.write("<tr>");
            writer.write("<td>Gender</td>");
            if(gender.equals("M"))
            {
                writer.write("<td><b>Male</b></td>");
            }
            else
            {
                writer.write("<td><b>Female</b></td>");
            }
            writer.write("</tr>");
            writer.write("<tr>");
            writer.write("<td>Date of birth</td>");
            writer.write("<td><b>"+dateOfBirth);
            writer.write("</b></td>");
            writer.write("</tr>");
            writer.write("<tr>");
            writer.write("<td>Contact</td>");
            writer.write("<td><b>"+contact);
            writer.write("</b></td>");
            writer.write("</tr>");
            writer.write("<tr>");
            writer.write("<td>City</td>");
            writer.write("<td><b>"+city);
            writer.write("</b></td>");
            writer.write("</tr>");
            writer.write("</table>");
            writer.write("<input type=\"submit\" value=\"Home\">");
            writer.write("</form>");
            writer.write("</body>");
            writer.write("</html>");
        }
        else
        {
            RequestDispatcher requestDispatcher=request.getRequestDispatcher("loginForm");
            requestDispatcher.include(request,response);
        }
        writer.close();
    }
}
