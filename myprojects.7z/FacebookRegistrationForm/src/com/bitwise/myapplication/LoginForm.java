package com.bitwise.myapplication;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created by arpitm on 7/27/2016.
 */
@WebServlet(name = "LoginForm")
public class LoginForm extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter writer=response.getWriter();
        writer.write("<!DOCTYPE html>");
        writer.write("<html lang=\"en\">");
        writer.write("<head>");
        writer.write("<meta charset=\"UTF-8\">");
        writer.write("<title>Facebook login</title>");
        writer.write("</head>");
        writer.write("<body>");
        writer.write("<h3>Facebook</h3>");
        writer.write("<form action=\"signupForm\" method=\"post\">");
        writer.write("<table>");
        writer.write("<tr>");
        writer.write("<td><input type=\"text\" id=\"username\" name=\"username\" maxlength=\"45\" size=\"30\" placeholder=\"Username\"></td> </tr>");
        writer.write("<tr>");
        writer.write("<td><input type=\"password\" id=\"password\" name=\"password\" maxlength=\"25\" size=\"30\" placeholder=\"Password\"></td>");
        writer.write("</tr>");
        writer.write("<tr>");
        writer.write("<td><input type=\"submit\" text=\"Login\"></td>");
        writer.write("</tr>");
        writer.write("</table>");
        writer.write("</form>");
        writer.write("</body>");
        writer.write("</html>");
        writer.close();
    }
}