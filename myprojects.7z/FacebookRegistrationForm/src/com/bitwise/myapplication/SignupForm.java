package com.bitwise.myapplication;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created by arpitm on 7/27/2016.
 */
@WebServlet(name = "SignupForm")
public class SignupForm extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

            String status=(String)request.getAttribute("status");
            PrintWriter writer=response.getWriter();
            if(status!=null)
            {
                    if(status.equals("valid"))
                    {
                            writer.write("<html>");
                            writer.write("<head>");
                            writer.write("<title>Create Profile</title>");
                            writer.write("<script>");
                            writer.write("function validateForm(frm)");
                            writer.write("{");
                            writer.write("alert('go');");
                            writer.write("}");
                            writer.write("</script>");
                            writer.write("</head>");
                            writer.write("<body>");
                            writer.write("<h3>Facebook</h3>");
                            writer.write("<form action=\"signupInformation\" method=\"post\" onSubmit=\"return validateForm(this)\">");
                            writer.write("<table>");
                            writer.write("<tr>");
                            writer.write("<td>Name</td>");
                            writer.write("<td><input type=\"text\" name=\"name\" id=\"name\"></td>");
                            writer.write("<td><span id=\"nameErrorSpan\"></span></td>");
                            writer.write("</tr>");
                            writer.write("<tr>");
                            writer.write("<td>Email</td>");
                            writer.write("<td><input type=\"email\" name=\"email\" id=\"email\"></td>");
                            writer.write("<td><span id=\"emailErrorSpan\"></span></td>");
                            writer.write("</tr>");
                            writer.write("<tr>");
                            writer.write("<td>Gender</td>");
                            writer.write("<td>&nbsp;&nbsp;&nbsp;Male<input type=\"radio\" id=\"male\" name=\"gender\" value=\"M\" checked>");
                            writer.write("Female<input type=\"radio\" id=\"female\" name=\"gender\" value=\"F\"></td>");
                            writer.write("</tr>");
                            writer.write("<tr>");
                            writer.write("<td>Date of birth</td>");
                            writer.write("<td><input type=\"date\" name=\"dateOfBirth\"></td>");
                            writer.write("<td><span id=\"dateOfBirthErrorSpan\"></span></td>");
                            writer.write("</tr>");
                            writer.write("<tr>");
                            writer.write("<td>Contact</td>");
                            writer.write("<td><input type=\"text\" name=\"contact\" id=\"contact\" ></td>");
                            writer.write("<td><span id=\"contactErrorSpan\"></span></td>");
                            writer.write("</tr>");
                            writer.write("<tr>");
                            writer.write("<td>City</td>");
                            writer.write("<td>");
                            writer.write("<select name=\"city\">");
                            writer.write("<option value=\"Pune\">Pune</option>");
                            writer.write("<option value=\"Nagpur\">Nagpur</option>");
                            writer.write("<option value=\"Ujjain\">Ujjain</option>");
                            writer.write("<option value=\"Indore\">Indore</option>");
                            writer.write("<option value=\"Bhopal\">Bhopal</option>");
                            writer.write("</select>");
                            writer.write("</td>");
                            writer.write("</tr>");
                            writer.write("<tr>");
                            writer.write("<td align=\"left\" colspan=\"2\"><input type=\"submit\" value=\"Signup\"></td>");
                            writer.write("</tr>");
                            writer.write("</table>");
                            writer.write("</form>");
                            writer.write("</body>");
                            writer.write("</html>");
                    }
                    else
                    {
                            writer.write("<!DOCTYPE html>");
                            writer.write("<html lang=\"en\">");
                            writer.write("<head>");
                            writer.write("<meta charset=\"UTF-8\">");
                            writer.write("<title>Facebook login</title>");
                            writer.write("</head>");
                            writer.write("<body>");
                            writer.write("<h3>Facebook</h3>");
                            writer.write("<form action=\"signupForm\" method=\"get\">");
                            writer.write("<table>");
                            writer.write("<tr>");
                            writer.write("<td><input type=\"text\" id=\"username\" name=\"username\" maxlength=\"45\" size=\"30\" placeholder=\"Username\"></td> </tr>");
                            writer.write("<tr>");
                            writer.write("<td><input type=\"password\" id=\"password\" name=\"password\" maxlength=\"25\" size=\"30\" placeholder=\"Password\"></td>");
                            writer.write("</tr>");
                            writer.write("<tr>");
                            writer.write("<td><b><span id=\"errorMessageSpan\">Invalid username/password combination</span></b></td>");
                            writer.write("</tr>");
                            writer.write("<tr>");
                            writer.write("<td><input type=\"submit\" text=\"Login\"></td>");
                            writer.write("</tr>");
                            writer.write("</table>");
                            writer.write("</form>");
                            writer.write("</body>");
                            writer.write("</html>");
                    }
            }
            else
            {
                    RequestDispatcher requestDispatcher=request.getRequestDispatcher("loginForm");
                    requestDispatcher.include(request,response);
            }
            writer.close();
            HttpSession session= request.getSession();
            session.invalidate();
    }
}
