/**
 * Created by arpitm on 7/28/2016.
 */
function validateForm(frm)
{
    alter('go');
    if(frm.name.trim().length==0)
    {
        document.getElementById("nameErrorSpan").innerHTML="Enter name";
        return false;
    }
    return true;
}