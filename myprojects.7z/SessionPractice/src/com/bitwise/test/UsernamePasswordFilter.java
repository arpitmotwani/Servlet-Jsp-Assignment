package com.bitwise.test;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.HashMap;

/**
 * Created by arpitm on 7/28/2016.
 */
@WebFilter(filterName = "UsernameFilter")
public class UsernamePasswordFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        String username=req.getParameter("username");
        String password=req.getParameter("password");
        String status=null;
        if(username!=null && password!=null)
        {
            if(username.equals("arpit.motwani@bitwiseglobal.com") && password.equals("arpit123"))
            {

                SecureRandom secureRandom=new SecureRandom();
                String token=secureRandom.generateSeed(1).toString();
                HashMap<String,String> database=new HashMap<>();
                database.put(username,token);


                Cookie[] cookies=(Cookie[]) req.getAttribute("cookies");
                if(cookies!=null)
                {
                    int x=0;
                    while(x<cookies.length)
                    {
                        if(cookies[x].getValue().equals(database.get(username)))break;
                        x++;
                    }
                    if(x>=cookies.length) System.out.println("Invalid session");
                    else System.out.println("Valid session");
                }
                Cookie myCookie=new Cookie("sessionCookie",token);
                req.setAttribute("myCookie",myCookie);
                status="valid";
            }
        }
        else
        {
            status="invalid";
        }
        req.setAttribute("status",status);
        chain.doFilter(req, resp);
}

    public void init(FilterConfig config) throws ServletException {

    }

}
