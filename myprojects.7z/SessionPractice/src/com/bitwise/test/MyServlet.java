package com.bitwise.test;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created by arpitm on 7/28/2016.
 */
@WebServlet(name = "MyServlet")
public class MyServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                PrintWriter writer=response.getWriter();
        if(request.getAttribute("status")!=null)
        {
            if(request.getAttribute("status").equals("valid"))
            {
                Cookie[] cookies= request.getCookies();
                System.out.println("Valid user");
                request.setAttribute("cookies",cookies);
            }
            else
            {
                System.out.println("invalid user");
            }
        }

    }
}
