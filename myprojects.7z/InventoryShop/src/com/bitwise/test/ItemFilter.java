package com.bitwise.test;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

/**
 * Created by arpitm on 7/27/2016.
 */
@WebFilter(filterName = "ItemFilter")
public class ItemFilter implements javax.servlet.Filter {
    public void destroy() {
        System.out.println("destroy is running()");
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        System.out.println("doFilter() is running before servlet");
        chain.doFilter(req, resp);
        System.out.println("doFilter() is running after servlet");
    }

    public void init(FilterConfig config) throws ServletException {
        System.out.println("init() is running");
    }

}
