package com.bitwise.servlets;

import org.omg.CORBA.Request;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Created by arpitm on 8/5/2016.
 */
@WebFilter(filterName = "ValidateLoginFilter")
public class ValidateLoginFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        String username=req.getParameter("username");
        String password=req.getParameter("password");
        if(("arpitm".equals(username) && "arpit".equals(password))||("arpit.motwani@bitwiseglobal.com".equals(username) && "arpit".equals(password)))
        {
            chain.doFilter(req, resp);
        }
        else
        {
            RequestDispatcher requestDispatcher;
            requestDispatcher=req.getRequestDispatcher("index.html");
            requestDispatcher.include(req,resp);
            requestDispatcher=req.getRequestDispatcher("UsernamePasswordError.html");
            requestDispatcher.include(req,resp);
        }

    }

    public void init(FilterConfig config) throws ServletException {

    }

}
