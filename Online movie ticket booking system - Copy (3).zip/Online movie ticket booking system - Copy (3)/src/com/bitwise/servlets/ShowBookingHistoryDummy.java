package com.bitwise.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by arpitm on 8/7/2016.
 */
@WebServlet(name = "ShowBookingHistoryDummy")
public class ShowBookingHistoryDummy extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Customer> customers=(ArrayList<Customer>)request.getSession().getAttribute("customers");
        for(Customer customer: customers)
        {
            System.out.println(customer.getCustomerName());
            System.out.println(customer.getCustomerAddress());
            System.out.println(customer.getCustomerPhone());
            System.out.println(customer.getDateOfBooking());
            System.out.println(customer.getMovieName());
            System.out.println(customer.getNumberOfSeatsBooked());
            System.out.println("--------------");
        }
    }
}
