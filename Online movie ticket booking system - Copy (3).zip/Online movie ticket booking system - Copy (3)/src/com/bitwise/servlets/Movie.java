package com.bitwise.servlets;

import java.util.HashMap;

/**
 * Created by arpitm on 8/5/2016.
 */
public class Movie {
    private String movieName;
    private String theaterName;
    private int totalSeatsAvailable;
    private String startTime;
    private String endTime;

    public String getMovieName() {
        return movieName;
    }

    public String getTheaterName() {
        return theaterName;
    }

    public int getTotalSeatsAvailable() {
        return totalSeatsAvailable;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setMovieName(String movieName) {

        this.movieName = movieName;
    }

    public void setTheaterName(String theaterName) {
        this.theaterName = theaterName;
    }

    public void setTotalSeatsAvailable(int totalSeatsAvailable) {
        this.totalSeatsAvailable = totalSeatsAvailable;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
}
