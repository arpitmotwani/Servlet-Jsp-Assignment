package com.bitwise.servlets;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by arpitm on 8/5/2016.
 */
public class MoviesCollection {
    private List<Movie> movies=new ArrayList<Movie>();
    public void addMovie(Movie movie)
    {
        movies.add(movie);
    }
    public List<Movie> getMovies()
    {
        return movies;
    }
    public int getSize()
    {
        return movies.size();
    }
    public Movie getAMovie(String movieName)
    {
        for(Movie movie: movies)
        {
            if(movie.getMovieName().equals(movieName))
            {
                return movie;
            }
        }
        return null;
    }

}
