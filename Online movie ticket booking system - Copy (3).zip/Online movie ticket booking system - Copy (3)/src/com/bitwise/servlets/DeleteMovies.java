package com.bitwise.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by arpitm on 8/5/2016.
 */
@WebServlet(name = "DeleteMovies")
public class DeleteMovies extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String movieName=request.getParameter("movieName");
        String theaterName=request.getParameter("theaterName");
        int totalSeatsAvailable=Integer.parseInt(request.getParameter("totalSeatsAvailable"));
        String startTime=request.getParameter("startTime");
        String endTime=request.getParameter("endTime");


        MoviesCollection moviesCollection=(MoviesCollection) request.getSession().getAttribute("moviesCollection");
        List<Movie> movies=moviesCollection.getMovies();
        for(int x=0;x<movies.size();x++)
        {
            if(movieName.equals(movies.get(x).getMovieName()) && theaterName.equals(movies.get(x).getTheaterName()) && totalSeatsAvailable==movies.get(x).getTotalSeatsAvailable() && startTime.equals(movies.get(x).getStartTime()) && endTime.equals(movies.get(x).getEndTime()))
            {
                movies.remove(x);
                break;
            }
        }
        request.getSession().setAttribute("moviesCollection",moviesCollection);
        request.getRequestDispatcher("/displayMovieShows").include(request,response);
        request.getRequestDispatcher("MovieDeletedSuccessfulMessage.html").include(request,response);

    }
}
