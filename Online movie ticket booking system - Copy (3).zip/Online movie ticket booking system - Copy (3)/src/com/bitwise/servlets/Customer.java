package com.bitwise.servlets;

/**
 * Created by arpitm on 8/7/2016.
 */
public class Customer {
    private String customerName;
    private String customerAddress;
    private String customerPhone;
    private String movieName;
    private String numberOfSeatsBooked;
    private String dateOfBooking;

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public String getMovieName() {
        return movieName;
    }

    public String getNumberOfSeatsBooked() {
        return numberOfSeatsBooked;
    }

    public String getDateOfBooking() {
        return dateOfBooking;
    }

    public void setCustomerName(String customerName) {

        this.customerName = customerName;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public void setNumberOfSeatsBooked(String numberOfSeatsBooked) {
        this.numberOfSeatsBooked = numberOfSeatsBooked;
    }

    public void setDateOfBooking(String dateOfBooking) {
        this.dateOfBooking = dateOfBooking;
    }
}