package com.bitwise.servlets;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by arpitm on 8/5/2016.
 */
@WebServlet(name = "AddMovieShow")
public class AddMovieShow extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            String movieName=request.getParameter("movieName");
            String theaterName=request.getParameter("theaterName");
            int totalSeatsAvailable=Integer.parseInt(request.getParameter("totalSeatsAvailable"));
            String startTime=request.getParameter("startTime");
            String endTime=request.getParameter("endTime");

            Movie movie=new Movie();
            movie.setMovieName(movieName);
            movie.setTheaterName(theaterName);
            movie.setTotalSeatsAvailable(totalSeatsAvailable);
            movie.setStartTime(startTime);
            movie.setEndTime(endTime);

            MoviesCollection moviesCollection;
            if(request.getSession().getAttribute("moviesCollection")!=null)
            {
            moviesCollection=(MoviesCollection)request.getSession().getAttribute("moviesCollection");
            }
            else
            {
                moviesCollection=new MoviesCollection();
            }

            if(moviesCollection.getSize()>10)
            {

                request.getRequestDispatcher("AddMovieShow.html").include(request,response);
                request.getRequestDispatcher("AddMovieErrorPage.html").include(request,response);

            }
            else
            {
                moviesCollection.addMovie(movie);
                request.getSession().setAttribute("moviesCollection",moviesCollection);
                request.getRequestDispatcher("AddMovieShow.html").include(request,response);
                request.getRequestDispatcher("MovieAddedSuccessfullMessage.html").include(request,response);
            }
    }

    public static class InvalidNumberOfSeatsException extends Throwable {
        private String message;
        public InvalidNumberOfSeatsException(String message) {
            this.message=message;
        }
        public String toString()
        {
            return this.message;
        }
    }
}
