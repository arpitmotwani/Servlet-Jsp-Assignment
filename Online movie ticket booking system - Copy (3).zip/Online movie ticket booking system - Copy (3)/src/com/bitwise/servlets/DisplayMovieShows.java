package com.bitwise.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

/**
 * Created by arpitm on 8/5/2016.
 */
@WebServlet(name = "DisplayMovieShows")
public class DisplayMovieShows extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter printWriter=response.getWriter();
        MoviesCollection moviesCollection=(MoviesCollection)request.getSession().getAttribute("moviesCollection");

        if(moviesCollection==null || moviesCollection.getSize()==0)
        {
            try {
                request.getRequestDispatcher("ShowNoMoviesToDisplayError.html").forward(request,response);
                throw new InvalidTotalNumberOfSeatsException("No movies to display");
            } catch (InvalidTotalNumberOfSeatsException e) {
                System.out.println(e);
            }
        }
        else
        {
            List<Movie> movies=moviesCollection.getMovies();
            for(Movie oldMovie: movies)
            {
                if(oldMovie.getTotalSeatsAvailable()==0)
                {
                    try {
                        request.getRequestDispatcher("ShowNoMoviesToDisplayError.html").forward(request,response);
                        throw new InvalidTotalNumberOfSeatsException("No movies to display");
                    } catch (InvalidTotalNumberOfSeatsException e) {
                        System.out.println(e);
                    }
                    break;
                }
            }
            printWriter.write("<html>");
            printWriter.write("<head>");
            printWriter.write("<title>Online movie ticket booking</title>");
            printWriter.write("</head>");
            printWriter.write("<body>");
            printWriter.write("<b><h2>All Movies</h2></b>");
            printWriter.write("<table border=\"1px\">");
            printWriter.write("<tr>");
            printWriter.write("<th>");
            printWriter.write("Movie name");
            printWriter.write("</th>");
            printWriter.write("<th>");
            printWriter.write("Theater name");
            printWriter.write("</th>");
            printWriter.write("<th>");
            printWriter.write("Total seats");
            printWriter.write("</th>");
            printWriter.write("<th>");
            printWriter.write("Start time");
            printWriter.write("</th>");
            printWriter.write("<th>");
            printWriter.write("End time");
            printWriter.write("</th>");
            printWriter.write("<th>");
            printWriter.write("Delete");
            printWriter.write("</th>");
            printWriter.write("</tr>");

                for(int x=0;x<movies.size();x++)
                {
                    String seats=String.valueOf(movies.get(x).getTotalSeatsAvailable());
                    printWriter.write("<tr>");
                    printWriter.write("<td>");
                    printWriter.write(movies.get(x).getMovieName());
                    printWriter.write("</td>");
                    printWriter.write("<td>");
                    printWriter.write(movies.get(x).getTheaterName());
                    printWriter.write("</td>");
                    printWriter.write("<td>");
                    printWriter.write(seats);
                    printWriter.write("</td>");
                    printWriter.write("<td>");
                    printWriter.write(movies.get(x).getStartTime());
                    printWriter.write("</td>");
                    printWriter.write("<td>");
                    printWriter.write(movies.get(x).getEndTime());
                    printWriter.write("</td>");
                    printWriter.write("<td>");

                    String queryString="<a href=\"deleteMovies?movieName=";
                    queryString=queryString+movies.get(x).getMovieName();
                    queryString=queryString+"&theaterName=";
                    queryString=queryString+movies.get(x).getTheaterName();
                    queryString=queryString+"&totalSeatsAvailable=";
                    queryString=queryString+movies.get(x).getTotalSeatsAvailable();
                    queryString=queryString+"&startTime=";
                    queryString=queryString+movies.get(x).getStartTime();
                    queryString=queryString+"&endTime=";
                    queryString=queryString+movies.get(x).getEndTime();
                    queryString=queryString+"\">Delete</a>";
                    printWriter.write(queryString);
/*
                    printWriter.write("<a href='deleteMovies?movieName=" +movies.get(x).getMovieName());
                    printWriter.write("&theaterName="+movies.get(x).getTheaterName());
                    printWriter.write("&totalSeatsAvailable="+movies.get(x).getTotalSeatsAvailable());
                    printWriter.write("&startTime="+movies.get(x).getStartTime());
                    printWriter.write("&endTime="+movies.get(x).getEndTime());
                    printWriter.write("'>Delete</a>");*/
                    printWriter.write("</td>");
                    printWriter.write("</tr>");

                }
            printWriter.write("</table><br>");
            printWriter.write("<a href=\"AdminModule.jsp\">Back</a>");
            printWriter.write("</body>");
            printWriter.write("</html>");
            printWriter.flush();
            printWriter.close();
        }
    }


    private class InvalidTotalNumberOfSeatsException extends Throwable {
        private String message;
        public InvalidTotalNumberOfSeatsException(String message) {
            this.message=message;
        }
        public String toString()
        {
            return this.message;
        }
    }
}
