package com.bitwise.servlets;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by arpitm on 8/6/2016.
 */
@WebFilter(filterName = "BookMovieShowFilter")
public class BookMovieShowFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        String customerName=req.getParameter("customerName");
        String customerAddress=req.getParameter("customerAddress");
        String customerPhone=req.getParameter("customerPhone");
        String movieName=req.getParameter("movie");
        String numberOfSeatsBooked=req.getParameter("numberOfSeatsBooked");
        String dateOfBooking=req.getParameter("dateOfBooking");

        HttpServletRequest request=(HttpServletRequest)req;
        //HttpServletResponse response=(HttpServletResponse)resp;

        if(customerName.trim().length()==0 || customerAddress.trim().length()==0 || customerPhone.trim().length()==0 || movieName.trim().length()==0 || numberOfSeatsBooked.trim().length()==0 || dateOfBooking.trim().length()==0)
        {
            req.getRequestDispatcher("BookMovie.jsp").include(req,resp);
            req.getRequestDispatcher("CredentialRequiredErrorMessage.html").include(req,resp);
        }
        else
        {
            if(Integer.parseInt(numberOfSeatsBooked)<=0)
            {
                req.getRequestDispatcher("BookMovie.jsp").include(req,resp);
                req.getRequestDispatcher("NumberOfSeatsLessThanZeroError.html").include(req,resp);
            }
            else
            {
                MoviesCollection moviesCollection=(MoviesCollection) request.getSession().getAttribute("moviesCollection");
                Movie movie=moviesCollection.getAMovie(movieName);
                        if(movie.getTotalSeatsAvailable()<Integer.parseInt(numberOfSeatsBooked))
                        {
                            req.getRequestDispatcher("SeatsNotAvailable.html").forward(req,resp);
                        }
                        else
                        {
                            System.out.println("?>"+(movie.getTotalSeatsAvailable()-Integer.parseInt(numberOfSeatsBooked)));
                            movie.setTotalSeatsAvailable(movie.getTotalSeatsAvailable()-Integer.parseInt(numberOfSeatsBooked));
                            request.getSession().setAttribute("moviesCollection",moviesCollection);
                            chain.doFilter(req, resp);
                        }

            }

        }
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
