package com.bitwise.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by arpitm on 8/6/2016.
 */
@WebServlet(name = "BookMovieShow")
public class BookMovieShow extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            //implementation starts here
        String customerName=request.getParameter("customerName");
        String customerAddress=request.getParameter("customerAddress");
        String customerPhone=request.getParameter("customerPhone");
        String movieName=request.getParameter("movie");
        String numberOfSeatsBooked=request.getParameter("numberOfSeatsBooked");
        String dateOfBooking=request.getParameter("dateOfBooking");

//        System.out.println(customerName);
//        System.out.println(customerAddress);
//        System.out.println(customerPhone);
//        System.out.println(movieName);
//        System.out.println(numberOfSeatsBooked);
//        System.out.println(dateOfBooking);

        Customer customer=new Customer();
        customer.setCustomerName(customerName);
        customer.setCustomerAddress(customerAddress);
        customer.setCustomerPhone(customerPhone);
        customer.setMovieName(movieName);
        customer.setNumberOfSeatsBooked(numberOfSeatsBooked);
        customer.setDateOfBooking(dateOfBooking);

        List<Customer> customers;
        if(request.getSession().getAttribute("customers")!=null)
        {
            customers=(ArrayList<Customer>)request.getSession().getAttribute("customers");
            //sort date ka logic
            Collections.sort(customers, new Comparator<Customer>() {
                public int compare(Customer m1, Customer m2) {
                    return m1.getDateOfBooking().compareTo(m2.getDateOfBooking());
                }
            });
            customers.add(customer);
        }
        else
        {
            customers=new ArrayList<Customer>();
            customers.add(customer);
        }
       request.getSession().setAttribute("customers",customers);
       request.getRequestDispatcher("UserModule.jsp").include(request,response);
       request.getRequestDispatcher("MovieBookedSuccessfullMessage.html").include(request,response);

    }
}
