package com.bitwise.servlets;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by arpitm on 8/5/2016.
 */
@WebFilter(filterName = "AddMovieShowFilter")
public class AddMovieShowFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        String movieName=req.getParameter("movieName");
        String theaterName=req.getParameter("theaterName");
        String totalSeatsAvailable=req.getParameter("totalSeatsAvailable");
        String startTime=req.getParameter("startTime");
        String endTime=req.getParameter("endTime");

        HttpServletRequest request=(HttpServletRequest)req;
        HttpServletResponse response=(HttpServletResponse)resp;



        if(movieName.trim().length()==0 || theaterName.trim().length()==0 || totalSeatsAvailable.trim().length()==0 || startTime.trim().length()==0 || endTime.trim().length()==0)
        {
            request.getRequestDispatcher("AddMovieShow.html").include(request,response);
            request.getRequestDispatcher("CredentialRequiredErrorMessage.html").include(request,response);
        }
        else
        {
            if(Integer.parseInt(totalSeatsAvailable)<=0)
            {
                try {
                    request.getRequestDispatcher("NumberOfSeatsLessThanZeroError.html").include(request,response);
                    throw new AddMovieShow.InvalidNumberOfSeatsException("Total number of seats cannot be negetive");
                } catch (AddMovieShow.InvalidNumberOfSeatsException e) {
                    System.out.println(e);
                }
                finally
                {
                    return;
                }
            }
            else
            {
                chain.doFilter(req, resp);
            }
        }

    }

    public void init(FilterConfig config) throws ServletException {

    }

}
