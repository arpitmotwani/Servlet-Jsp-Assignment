package com.bitwise.servlets;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Random;

/**
 * Created by arpitm on 8/6/2016.
 */
@WebFilter(filterName = "ValidateSessionFilter")
public class ValidateSessionFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        System.out.println("ValidateSession filter gets called");
        HttpServletRequest request=(HttpServletRequest)req;
        HttpServletResponse response=(HttpServletResponse)resp;

        String username= (String)request.getSession().getAttribute("username");
        System.out.println("&&&&&&&&->"+username);
        HashMap<String,String> newDB=(HashMap<String, String>) request.getServletContext().getAttribute("database");
        if(newDB!=null)
        {
            Cookie[] cookies=request.getCookies();
            if(cookies!=null)
            {
                String value="";
                String id="";
                System.out.println("Yaha aaya");
                for(Cookie cookie:cookies)
                {
                    if(cookie.getName().equals("uniqueID"))
                    {
                        System.out.println("##->"+cookie.getValue());
                        value=cookie.getValue();
                        break;
                    }
                }
                for(String uID:newDB.values())
                {
                    System.out.println("$$->"+uID);
                    id=uID;
                    break;
                }
                System.out.println(">>>>"+value);
                System.out.println("<<<<"+id);
                if(value.equals(id))
                {
                    chain.doFilter(req, resp);
                }
                else
                {
                    request.getRequestDispatcher("index.html").forward(req,resp);
                }
            }
            else
            {
                System.out.println("cookie request me add ni hui");
            }
        }
        else
        {
            if(username!=null)
            {
                System.out.println("ELSE me gaya");
                String uniqueID=java.util.UUID.randomUUID().toString();
                HashMap<String,String> database= new HashMap<>();
                database.put(username,uniqueID);
                Cookie loginCookie=new Cookie("uniqueID",uniqueID);
                response.addCookie(loginCookie);
                request.getServletContext().setAttribute("database",database);
                chain.doFilter(req,resp);
            }
            else
            {
                request.getRequestDispatcher("index.html").forward(req,resp);
            }
        }

    }

    public void init(FilterConfig config) throws ServletException {

    }

}
