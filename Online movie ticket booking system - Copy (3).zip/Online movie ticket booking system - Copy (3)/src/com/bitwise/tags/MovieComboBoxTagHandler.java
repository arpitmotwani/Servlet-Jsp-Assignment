package com.bitwise.tags;

import com.bitwise.servlets.Movie;
import com.bitwise.servlets.MoviesCollection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import javax.servlet.jsp.tagext.TagSupport;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by arpitm on 8/6/2016.
 */
public class MovieComboBoxTagHandler extends SimpleTagSupport {
    public void doTag() throws JspException,IOException
    {
        PageContext pageContext=(PageContext) getJspContext();
        JspWriter writer=pageContext.getOut();
        HttpServletRequest request=(HttpServletRequest)pageContext.getRequest();
        HttpServletResponse response=(HttpServletResponse)pageContext.getResponse();
        //HttpServletResponse response=(HttpServletResponse)pageContext.getResponse();
        MoviesCollection moviesCollection=(MoviesCollection)request.getSession().getAttribute("moviesCollection");
        if(moviesCollection==null || moviesCollection.getSize()==0)
        {
            try {
                request.getRequestDispatcher("CannotBookMovies.html").forward(request,response);
            } catch (ServletException e) {
                e.printStackTrace();
            }
        }
        else
        {
            List<Movie> movies=moviesCollection.getMovies();
            writer.write("<select name=\"movie\" id=\"movie\">");
            for(Movie movie:movies)
            {
                writer.write("<option value='"+movie.getMovieName()+"'>"+movie.getMovieName()+"</option>");
//            writer.write("<input type=\"hidden\" movieName='"+movie.getMovieName()+"'>");
//            writer.write("<input type=\"hidden\" theaterName='"+movie.getTheaterName()+"'>");
//            writer.write("<input type=\"hidden\" totalSeatsAvailable='"+movie.getTotalSeatsAvailable()+"'>");
//            writer.write("<input type=\"hidden\" startTime='"+movie.getStartTime()+"'>");
//            writer.write("<input type=\"hidden\" endTime='"+movie.getEndTime()+"'>");
            }
            writer.write("</select>");
        }
    }
}
