/**
 * Created by Arpit on 7/31/2016.
 */
function validateLoginForm(frm)
{
    if(frm.username.value.length==0)
    {
        document.getElementById("loginFormUsernameErrorSpan").innerHTML="Username required";
        document.getElementById("loginFormPasswordErrorSpan").innerHTML="";
        return false;
    }
    if(frm.password.value.length==0)
    {
        document.getElementById("loginFormUsernameErrorSpan").innerHTML="";
        document.getElementById("loginFormPasswordErrorSpan").innerHTML="Password required";
        return false;
    }
    return true;
}