package com.bitwise.test;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashSet;

/**
 * Created by Arpit on 7/31/2016.
 */
@WebServlet(name = "ValidateLogin")
public class ValidateLogin extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String status=(String)request.getAttribute("status");
        RequestDispatcher requestDispatcher;
        if(status.equals("invalidUsernamePasswordCombination"))
        {
            requestDispatcher=request.getRequestDispatcher("index.jsp");
            requestDispatcher.include(request,response);
            requestDispatcher=request.getRequestDispatcher("LoginErrorMessage.html");
            requestDispatcher.include(request,response);
        }
        if(status.equals("true"))
        {
            HashSet<String> cart=new HashSet<String>();
            cart.add("Puma Shoes");
            cart.add("Addidas Shoes");
            cart.add("Nike Shoes");
            cart.add("Puma Floaters");
            cart.add("Nivia Football");
            cart.add("Nike Hypervenum Shoes");
            request.getServletContext().setAttribute("cart",cart);
            requestDispatcher=request.getRequestDispatcher("DisplayMenu.jsp");
            requestDispatcher.forward(request,response);
        }
        if(status.equals("false"))
        {
            requestDispatcher=request.getRequestDispatcher("index.jsp");
            requestDispatcher.forward(request,response);
        }
    }
}
