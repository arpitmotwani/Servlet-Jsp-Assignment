/**
 * Created by arpitm on 7/29/2016.
 */
function  validateCreateResidentialProfileForm(frm)
{
    if (frm.name.value.length == 0) {
        document.getElementById("createProfileNameErrorSpan").innerHTML = "Name required";
        document.getElementById("createProfileEmailErrorSpan").innerHTML = "";
        document.getElementById("createProfileContactNumberErrorSpan").innerHTML = "";
        document.getElementById("createProfileDateOfBirthErrorSpan").innerHTML = "";
        return false;
    }
    if (frm.email.value.length == 0) {
        document.getElementById("createProfileNameErrorSpan").innerHTML = "";
        document.getElementById("createProfileEmailErrorSpan").innerHTML = "Email required";
        document.getElementById("createProfileContactNumberErrorSpan").innerHTML = "";
        document.getElementById("createProfileDateOfBirthErrorSpan").innerHTML = "";
        return false;
    }
    if (frm.contactNumber.value.length == 0) {
        document.getElementById("createProfileNameErrorSpan").innerHTML = "";
        document.getElementById("createProfileEmailErrorSpan").innerHTML = "";
        document.getElementById("createProfileContactNumberErrorSpan").innerHTML = "Contact required";
        document.getElementById("createProfileDateOfBirthErrorSpan").innerHTML = "";
        return false;
    }
    if (frm.contactNumber.value.length < 10) {
        document.getElementById("createProfileNameErrorSpan").innerHTML = "";
        document.getElementById("createProfileEmailErrorSpan").innerHTML = "";
        document.getElementById("createProfileContactNumberErrorSpan").innerHTML = "Invalid contact number";
        document.getElementById("createProfileDateOfBirthErrorSpan").innerHTML = "";
        return false;
    }
    if (frm.dateOfBirth.value.length == 0) {
        document.getElementById("createProfileNameErrorSpan").innerHTML = "";
        document.getElementById("createProfileEmailErrorSpan").innerHTML = "";
        document.getElementById("createProfileContactNumberErrorSpan").innerHTML = "";
        document.getElementById("createProfileDateOfBirthErrorSpan").innerHTML = "Date of birth required";
        return false;
    }
    if (document.getElementById("male").value == "male")
    {
        frm.gender="male";
    }
    else
    {
        frm.gender="female";
    }
    return true;
}
function validateCreateOccupationalProfileForm(frm)
{
    if(frm.name.value.length==0)
    {
        document.getElementById("createOccupationalProfileNameErrorSpan").innerHTML="Name required";
        document.getElementById("createOccupationalProfileEmailErrorSpan").innerHTML="";
        document.getElementById("CompanyNameErrorSpan").innerHTML="";
        document.getElementById("profileErrorSpan").innerHTML="";
        return false;
    }
    if(frm.email.value.length==0)
    {
        document.getElementById("createOccupationalProfileNameErrorSpan").innerHTML="";
        document.getElementById("createOccupationalProfileEmailErrorSpan").innerHTML="Email required";
        document.getElementById("CompanyNameErrorSpan").innerHTML="";
        document.getElementById("profileErrorSpan").innerHTML="";
        return false;
    }
    if(frm.companyName.value.length==0)
    {
        document.getElementById("createOccupationalProfileNameErrorSpan").innerHTML="";
        document.getElementById("createOccupationalProfileEmailErrorSpan").innerHTML="";
        document.getElementById("CompanyNameErrorSpan").innerHTML="Company name required";
        document.getElementById("profileErrorSpan").innerHTML="";
        return false;
    }
    if(frm.profile.value.length==0)
    {
        document.getElementById("createOccupationalProfileNameErrorSpan").innerHTML="";
        document.getElementById("createOccupationalProfileEmailErrorSpan").innerHTML="";
        document.getElementById("CompanyNameErrorSpan").innerHTML="";
        document.getElementById("profileErrorSpan").innerHTML="Profile required";
        return false;
    }
    return true;
}
function validateCreateEducationalProfileForm(frm) {
    if(frm.schoolOrCollegeName.value.length==0)
    {
        document.getElementById("schoolOrCollegeNameErrorSpan").innerHTML="School/college name required";
        document.getElementById("cgpaOrPercentageErrorSpan").innerHTML="";
        return false;
    }
    if(frm.cgpaOrPercentage.value.length==0)
    {
        document.getElementById("schoolOrCollegeNameErrorSpan").innerHTML="";
        document.getElementById("cgpaOrPercentageErrorSpan").innerHTML="CGPA/Percentage required";
        return false;
    }
    return true;
}

function validateForm(frm)
{
    if(frm.signupUsername.value.length==0)
    {
        document.getElementById("signupUsernameErrorSpan").innerHTML="Username required";
        document.getElementById("signupPasswordErrorSpan").innerHTML="";
        document.getElementById("signupConfirmPasswordErrorSpan").innerHTML="";
        return false;
    }
    if(frm.signupPassword.value.length==0)
    {
        document.getElementById("signupPasswordErrorSpan").innerHTML="Password required";
        document.getElementById("signupUsernameErrorSpan").innerHTML="";
        document.getElementById("signupConfirmPasswordErrorSpan").innerHTML="";
        return false;
    }
    if(frm.signupConfirmPassword.value.length==0)
    {
        document.getElementById("signupConfirmPasswordErrorSpan").innerHTML="Password required";
        document.getElementById("signupPasswordErrorSpan").innerHTML="";
        document.getElementById("signupUsernameErrorSpan").innerHTML="";
        return false;
    }
    if(frm.signupConfirmPassword.value!=frm.signupPassword.value)
    {
        document.getElementById("signupConfirmPasswordErrorSpan").innerHTML="Incorred password";
        document.getElementById("signupPasswordErrorSpan").innerHTML="";
        document.getElementById("signupUsernameErrorSpan").innerHTML="";
        return false;
    }
    return true;
}

function validateLoginForm(frm)
{
    if(frm.loginUsername.value.length==0)
    {
        document.getElementById("loginUsernameErrorSpan").innerHTML="Enter username";
        document.getElementById("loginPasswordErrorSpan").innerHTML="";
        return false;
    }
    if(frm.loginPassword.value.length==0)
    {
        document.getElementById("loginUsernameErrorSpan").innerHTML="";
        document.getElementById("loginPasswordErrorSpan").innerHTML="Enter password";
        return false;
    }
    return true;
}
