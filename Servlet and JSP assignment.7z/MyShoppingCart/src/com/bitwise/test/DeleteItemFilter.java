package com.bitwise.test;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

/**
 * Created by arpitm on 8/2/2016.
 */
@WebFilter(filterName = "DeleteItemFilter")
public class DeleteItemFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        String status;
        String name=(String)req.getParameter("name");
        if(req.getServletContext().getAttribute("username")!=null)
        {
            status="Yes";
        }
        else
        {
            status="No";
        }
        req.setAttribute("name",name);
        req.setAttribute("status",status);
        chain.doFilter(req, resp);
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
