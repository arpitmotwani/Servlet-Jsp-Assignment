package com.bitwise.test;

import com.bitwise.test.bean.ItemBean;
import com.sun.javaws.Main;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

/**
 * Created by arpitm on 8/2/2016.
 */
@WebFilter(filterName = "AddItemFilter")
public class AddItemFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        System.out.println("--> IN filter");
//        String itemName=req.getParameter("itemName");
//        ItemBean itemBean=new ItemBean();
//        itemBean.setItemName(itemName);
//
//        String usePreviousDatabase;
//        MaintainItemDatabase maintainItemDatabase;
//
//        if(req.getServletContext().getAttribute("maintainItemDatabase")!=null)
//        {
//            usePreviousDatabase="yes";
//            maintainItemDatabase=(MaintainItemDatabase)req.getServletContext().getAttribute("maintainItemDatabase");
//        }
//        else
//        {
//            usePreviousDatabase="no";
//            maintainItemDatabase=new MaintainItemDatabase();
//        }
//        req.setAttribute("itemBean",itemBean);
//        req.setAttribute("usePreviousDatabase",usePreviousDatabase);
//        req.getServletContext().setAttribute("maintainItemDatabase",maintainItemDatabase);
        chain.doFilter(req, resp);
    }

    public void init(FilterConfig config) throws ServletException {
    }

}
