package com.bitwise.test;

        import javax.servlet.RequestDispatcher;
        import javax.servlet.ServletException;
        import javax.servlet.annotation.WebServlet;
        import javax.servlet.http.HttpServlet;
        import javax.servlet.http.HttpServletRequest;
        import javax.servlet.http.HttpServletResponse;
        import java.io.IOException;

/**
 * Created by Arpit on 7/31/2016.
 */
@WebServlet(name = "ValidateLogin")
public class ValidateLogin extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username=(String)request.getAttribute("username");
        //System.out.println("ValidateLoginServlet - > username : "+username);
        String status=(String)request.getAttribute("status");
        RequestDispatcher requestDispatcher;
        if(username!=null)
        {
            if("invalidUsernamePasswordCombination".equals(status))
            {
                requestDispatcher=request.getRequestDispatcher("index.jsp");
                requestDispatcher.include(request,response);
                requestDispatcher=request.getRequestDispatcher("LoginErrorMessage.html");
                requestDispatcher.include(request,response);
            }
            if("true".equals(status))
            {
                requestDispatcher=request.getRequestDispatcher("DisplayItem.jsp");
                requestDispatcher.forward(request,response);
            }
            if("false".equals(status))
            {
                requestDispatcher=request.getRequestDispatcher("index.jsp");
                requestDispatcher.forward(request,response);
            }
        }
        else
        {
            requestDispatcher=request.getRequestDispatcher("index.jsp");
            requestDispatcher.forward(request,response);
        }
        request.getServletContext().setAttribute("username",username);
    }
}
