package com.bitwise.test;

import com.bitwise.test.bean.ItemBean;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
//import java.util.HashSet;

/**
 * Created by arpitm on 8/2/2016.
 */
@WebServlet(name = "AddItem")
public class AddItem extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("--> IN Servlet");
//        String usePreviousDatabase=(String)request.getAttribute("usePreviousDatabase");
//
//        MaintainItemDatabase maintainItemDatabase;
//        RequestDispatcher requestDispatcher;
//
//        ItemBean itemBean=(ItemBean) request.getAttribute("itemBean");
//
//
//        if(usePreviousDatabase==null)
//        {
//            requestDispatcher=request.getRequestDispatcher("index.jsp");
//            requestDispatcher.forward(request,response);
//        }
//        else
//        {
//            if("yes".equals(usePreviousDatabase))
//            {
//                maintainItemDatabase=(MaintainItemDatabase)request.getServletContext().getAttribute("maintainItemDatabase");
//            }
//            else
//            {
//                maintainItemDatabase=new MaintainItemDatabase();
//            }
//            request.getServletContext().removeAttribute(usePreviousDatabase);
//            maintainItemDatabase.addItems(itemBean.getItemName());
//            request.getServletContext().setAttribute("maintainItemDatabase",maintainItemDatabase);
//            request.getSession().setAttribute("maintainItemDatabase",maintainItemDatabase);
//
//        }
//
//
//        requestDispatcher=request.getRequestDispatcher("DisplayItem.jsp");
//        requestDispatcher.include(request,response);
//        requestDispatcher=request.getRequestDispatcher("SuccessfullyItemAddedMessage.html");
//        requestDispatcher.include(request,response);
    }
}