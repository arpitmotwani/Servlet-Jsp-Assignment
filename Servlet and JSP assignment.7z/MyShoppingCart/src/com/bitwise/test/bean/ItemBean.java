package com.bitwise.test.bean;

/**
 * Created by arpitm on 8/2/2016.
 */
public class ItemBean {
    private String itemName;

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName)
    {
        this.itemName = itemName;
    }
}