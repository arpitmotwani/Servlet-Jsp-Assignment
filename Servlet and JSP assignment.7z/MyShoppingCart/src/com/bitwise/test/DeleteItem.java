package com.bitwise.test;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by arpitm on 8/2/2016.
 */
@WebServlet(name = "DeleteItem")
public class DeleteItem extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String status=(String)request.getAttribute("status");
        String iName=(String)request.getAttribute("name");
        RequestDispatcher requestDispatcher;
        MaintainItemDatabase maintainItemDatabase=(MaintainItemDatabase)request.getServletContext().getAttribute("maintainItemDatabase");

        if(maintainItemDatabase!=null)
        {
            if("yes".equalsIgnoreCase(status))
            {
                for(String name: maintainItemDatabase.getItems())
                {
                    if(name.equalsIgnoreCase(iName))
                    {
                        maintainItemDatabase.getItems().remove(iName);
                        break;
                    }
                }
                requestDispatcher=request.getRequestDispatcher("DisplayItem.jsp");
                requestDispatcher.include(request,response);
                requestDispatcher=request.getRequestDispatcher("DeleteItemSuccessfullMessage.html");
                requestDispatcher.include(request,response);
            }
            else
            {
                requestDispatcher=request.getRequestDispatcher("index.jsp");
                requestDispatcher.forward(request,response);
            }
        }
        else
        {
            requestDispatcher=request.getRequestDispatcher("NoItemsErrorMessage.html");
            requestDispatcher.forward(request,response);
        }
        //System.out.println(status);
    }
}
