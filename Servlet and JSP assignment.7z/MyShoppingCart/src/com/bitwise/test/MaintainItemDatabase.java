package com.bitwise.test;

import java.util.HashSet;

/**
 * Created by arpitm on 8/2/2016.
 */
public class MaintainItemDatabase {
    private HashSet<String> items=new HashSet<String>();
    public void addItems(String item)
    {
        items.add(item);
    }
    public HashSet<String> getItems()
    {
        return this.items;
    }
    public int hashSetSize()
    {
        return items.size();
    }

}