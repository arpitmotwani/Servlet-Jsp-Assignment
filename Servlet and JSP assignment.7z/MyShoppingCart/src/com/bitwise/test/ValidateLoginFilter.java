package com.bitwise.test;

import com.bitwise.test.bean.ItemBean;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

/**
 * Created by Arpit on 7/31/2016.
 */
@WebFilter(filterName = "ValidateLoginFilter")
public class ValidateLoginFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        String username= req.getParameter("username");
        String password= req.getParameter("password");
        String status="false";
        if(username!=null && password!=null)
        {
            if(("arpit.motwani@bitwiseglobal.com".equals(username) && "arpitmotwani".equals(password)) || ("rohit.sharma@bitwiseglobal.com".equals(username) && "rohitsharma".equals(password)) || (username.equals("shikhar.dhavan@bitwiseglobal.com") && password.equals("shikhardhavan")) || (username.equals("virat.kohli@bitwiseglobal.com") && password.equals("viratkohli")))
            {
                status="true";
            }
            else
            {
                status="invalidUsernamePasswordCombination";
            }
        }
        else
        {
            //check krna hai ki username or password match kr rhe hai ya ni. agar
            //match kr rhe hai to aage forward krna hai otherwise index.jsp pr
            //forward krna hai
        }
        req.setAttribute("status",status);
        req.setAttribute("username",username);
        chain.doFilter(req, resp);
    }

    public void init(FilterConfig config) throws ServletException {
        MaintainItemDatabase maintainItemDatabase=new MaintainItemDatabase();
        maintainItemDatabase.addItems("Addidas shoes");
        maintainItemDatabase.addItems("Nike shoes");
        maintainItemDatabase.addItems("Puma shoes");
        maintainItemDatabase.addItems("Sparx shoes");
    }

}