package com.bitwise.test;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Arpit on 7/31/2016.
 */
@WebServlet(name = "DisplayResidentialProfile")
public class DisplayResidentialProfile extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String status=(String)request.getServletContext().getAttribute("status");
        RequestDispatcher requestDispatcher;
        if(status.equals("false"))
        {
            requestDispatcher=request.getRequestDispatcher("index.jsp");
            requestDispatcher.forward(request,response);
        }
        if(status.equals("true"))
        {
//            String name=(String)request.getAttribute("name");
//            String email=(String)request.getAttribute("email");
//            String contactNumber=(String)request.getAttribute("contactNumber");
//            String dateOfBirth=(String)request.getAttribute("dateOfBirth");
//            String gender=(String)request.getAttribute("gender");
//            String city=(String)request.getAttribute("city");
//
//            request.getServletContext().setAttribute("name",name);
//            request.getServletContext().setAttribute("email",email);
//            request.getServletContext().setAttribute("contactNumber",contactNumber);
//            request.getServletContext().setAttribute("dateOfBirth",dateOfBirth);
//            request.getServletContext().setAttribute("gender",gender);
//            request.getServletContext().setAttribute("city",city);

            requestDispatcher=request.getRequestDispatcher("ShowResidentialInformation.jsp");
            requestDispatcher.forward(request,response);
        }
//        if(status.equals("remainsAtCreateProfilePage"))
//        {
//            requestDispatcher=request.getRequestDispatcher("CreateNewProfile.jsp");
//            requestDispatcher.forward(request,response);
//        }
    }
}
