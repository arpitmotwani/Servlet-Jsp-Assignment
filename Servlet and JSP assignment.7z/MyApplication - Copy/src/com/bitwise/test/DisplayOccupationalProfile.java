package com.bitwise.test;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by arpitm on 8/1/2016.
 */
@WebServlet(name = "DisplayOccupationalProfile")
public class DisplayOccupationalProfile extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String status=(String)request.getServletContext().getAttribute("status");
        RequestDispatcher requestDispatcher;
        if(status.equals("false"))
        {
            requestDispatcher=request.getRequestDispatcher("index.jsp");
            requestDispatcher.forward(request,response);
        }
        if(status.equals("true"))
        {
//            String name=(String)request.getAttribute("name");
//            String email=(String)request.getAttribute("email");
//            String companyName=(String)request.getAttribute("companyName");
//            String profile=(String)request.getAttribute("profile");

//            request.getServletContext().setAttribute("name",name);
//            request.getServletContext().setAttribute("email",email);
//            request.getServletContext().setAttribute("companyName",companyName);
//            request.getServletContext().setAttribute("profile",profile);

            requestDispatcher=request.getRequestDispatcher("ShowOccupationalInformation.jsp");
            requestDispatcher.forward(request,response);
        }
//        if(status.equals("remainsAtCreateProfilePage"))
//        {
//            requestDispatcher=request.getRequestDispatcher("CreateNewProfile.jsp");
//            requestDispatcher.forward(request,response);
//        }
    }
}
