package com.bitwise.test;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

/**
 * Created by arpitm on 8/1/2016.
 */
@WebFilter(filterName = "DisplayEducationalProfileFilter")
public class DisplayEducationalProfileFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        String username=(String)req.getServletContext().getAttribute("username");
        String password=(String)req.getServletContext().getAttribute("password");
        String status="false";
        String recentEducationalQualification=req.getParameter("recentEducationalQualification");
        String passingYear=req.getParameter("passingYear");
        String schoolOrCollegeName=req.getParameter("schoolOrCollegeName");
        String cgpaOrPercentage=req.getParameter("cgpaOrPercentage");


//        System.out.println("req"+recentEducationalQualification);
//        System.out.println("py"+passingYear);
//        System.out.println("socn"+schoolOrCollegeName);
//        System.out.println("cop"+cgpaOrPercentage);
        if(username!=null && password!=null)
        {
            System.out.println("1");
            if(recentEducationalQualification!=null && passingYear!=null && schoolOrCollegeName!=null && cgpaOrPercentage!=null)
            {
                status="true";
                req.setAttribute("recentEducationalQualification",recentEducationalQualification);
                req.setAttribute("passingYear",passingYear);
                req.setAttribute("schoolOrCollegeName",schoolOrCollegeName);
                req.setAttribute("cgpaOrPercentage",cgpaOrPercentage);
            }
            else
            {
                status="false";
            }
        }
        req.getServletContext().setAttribute("status",status);
        chain.doFilter(req, resp);
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
