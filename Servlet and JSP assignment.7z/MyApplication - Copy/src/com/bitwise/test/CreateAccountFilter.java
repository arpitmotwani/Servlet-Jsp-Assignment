package com.bitwise.test;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;
import java.util.HashMap;

/**
 * Created by arpitm on 7/29/2016.
 */
//@WebFilter(filterName = "CreateAccountFilter")
public class CreateAccountFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        String username=req.getParameter("signupUsername");
        String password=req.getParameter("signupPassword");
        String status="true";
        if(username!=null && password!=null)
        {
            if(req.getServletContext().getAttribute("usernameAndPasswords")!=null)
            {
                HashMap<String,String> usernameAndPasswords=(HashMap<String, String>)req.getServletContext().getAttribute("usernameAndPasswords");
                for(String hashmapUsername:usernameAndPasswords.keySet())
                {
                    if(username.equalsIgnoreCase(hashmapUsername))
                    {
                        status="false";
                        break;
                    }
                }
            }
            else
            {
                //"Invalid username and password
            }
        }
        else
        {
            status="goToLoginForm";
        }
        req.getServletContext().setAttribute("status",status);
        req.getServletContext().setAttribute("username",username);
        req.getServletContext().setAttribute("password",password);
        chain.doFilter(req, resp);
    }

    public void init(FilterConfig config) throws ServletException {

    }

}

